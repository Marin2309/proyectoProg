from typing import Dict, Any

class Alumno:
    def __init__(self, id: str, nombre: str, apellido: str, email: str, dni: str, curso: str):
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.dni = dni
        self.curso = curso

    def a_dict(self) -> Dict[str, str]:
        return {
            'id': self.id,
            'nombre': self.nombre,
            'apellido': self.apellido,
            'email': self.email,
            'dni': self.dni,
            'curso': self.curso
        }


