from alumno import Alumno
from gestores.gestor_alumnos import GestorAlumnos
from typing import List, Dict, Optional
import re
import os

gestor_alumnos = GestorAlumnos()

def listar_alumnos() -> None:
    print("\n--- Lista de alumnos ---")
    for alumno in gestor_alumnos.listar():
        print(alumno.a_dict())

def validar_email(email: str) -> bool:
    # Validar el formato del email
    regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(regex, email) is not None

def agregar_alumno() -> None:
    print("\n--- Agregar alumno ---")

    id: str = input("ID: ")

    nombre: str = ""
    while not nombre:
        nombre = input("Nombre (obligatorio): ")
        if not nombre:
            print("El nombre es obligatorio.")

    apellido: str = ""
    while not apellido:
        apellido = input("Apellido (obligatorio): ")
        if not apellido:
            print("El apellido es obligatorio.")

    email: str = ""
    while not validar_email(email):
        email = input("Email (debe ser válido, ej. ejemplo@gmail.com): ")
        if not validar_email(email):
            print("Email no válido. Por favor, introduzca un email correcto.")

    dni: str = ""
    while not dni:
        dni = input("DNI (obligatorio): ")
        if any(a.dni == dni for a in gestor_alumnos.listar()):
            print("El DNI ya existe. Por favor, introduce uno diferente.")
            dni = ""

    curso: str = input("Curso: ")

    alumno: Alumno = Alumno(id, nombre, apellido, email, dni, curso)  # Incluir curso
    gestor_alumnos.agregar(alumno)

def importar_alumnos() -> None:
    ruta_importacion: str = input("Ingrese la ruta absoluta del archivo CSV a importar: ")
    gestor_alumnos.importar(ruta_importacion)

def exportar_alumnos() -> None:
    ruta_exportacion: str = input("Ingrese la ruta absoluta donde desea exportar el archivo CSV: ")
    gestor_alumnos.exportar(ruta_exportacion)

def borrar_alumno() -> None:
    print("\n--- Borrar alumno ---")
    id: str = input("ID del alumno a borrar: ")
    gestor_alumnos.borrar(id)

def filtrar_alumnos() -> None:
    print("\n--- Filtrar alumnos por nombre ---")
    nombre: str = input("Nombre a buscar: ")
    filtrados: List[Alumno] = gestor_alumnos.filtrar_por_nombre(nombre)
    for alumno in filtrados:
        print(alumno.a_dict())

def editar_alumno() -> None:
    print("\n--- Editar alumno ---")
    id: str = input("ID del alumno a editar: ")

    nombre: str = ""
    while not nombre:
        nombre = input("Nuevo nombre (obligatorio): ")
        if not nombre:
            print("El nombre es obligatorio.")

    apellido: str = ""
    while not apellido:
        apellido = input("Nuevo apellido (obligatorio): ")
        if not apellido:
            print("El apellido es obligatorio.")

    email: str = ""
    while not validar_email(email):
        email = input("Nuevo email (debe ser válido): ")
        if not validar_email(email):
            print("Email no válido. Por favor, introduzca un email correcto.")

    dni: str = ""
    while not dni:
        dni = input("Nuevo DNI (obligatorio): ")
        if any(a.dni == dni for a in gestor_alumnos.listar() if a.id != id):
            print("El DNI ya existe. Por favor, introduce uno diferente.")
            dni = ""

    curso: str = input("Nuevo curso: ")

    nuevos_datos: Dict[str, str] = {}
    if nombre:
        nuevos_datos['nombre'] = nombre
    if apellido:
        nuevos_datos['apellido'] = apellido
    if email:
        nuevos_datos['email'] = email
    if dni:
        nuevos_datos['dni'] = dni
    if curso:
        nuevos_datos['curso'] = curso

    gestor_alumnos.editar(id, nuevos_datos)

def cargar_alumnos() -> None:
    gestor_alumnos.cargar()
    print("Datos cargados desde el archivo.")

def borrar_todo_alumnos() -> None:
    alumnos = gestor_alumnos.listar()
    for alumno in alumnos:
        gestor_alumnos.borrar(alumno.id)
    print("Todos los alumnos han sido eliminados.")

def guardar_alumnos() -> None:
    gestor_alumnos.guardar()
    print("Datos de alumnos guardados en el archivo.")

def buscar_y_mostrar_alumno() -> None:
    alumno_id: str = input("Ingresa el ID del alumno a buscar: ")
    alumno: Optional[Alumno] = gestor_alumnos.buscar_alumno_por_id(alumno_id)
    if alumno:
        print("Alumno encontrado:")
        print(alumno.a_dict())
    else:
        print("Alumno no encontrado.")

def importar_fichero() -> None:
    ruta_importacion: str = 'importar/alumnos.csv'
    gestor_alumnos.importar_alumno(ruta_importacion)

def exportar_fichero() -> None:
    ruta_exportacion: str = 'exportar/alumnos.csv'
    gestor_alumnos.exportar_alumnos(ruta_exportacion)

