from funciones.funciones_prestamos import gestor_prestamos
from libro import Libro
from gestores.gestor_libros import GestorLibros
from typing import List, Optional


gestor_libros = GestorLibros()

def listar_libros() -> None:
    print("\n--- Lista de libros ---")
    for libro in gestor_libros.listar():
        print(libro.__dict__)

def agregar_libro() -> None:
    print("\n--- Agregar libro ---")
    codigo: str = input("Código: ")
    titulo: str = input("Título: ")
    autor: str = input("Autor: ")
    materia : str = input("Materia: ")
    libro: Libro = Libro(codigo, titulo, autor, materia, disponible=True)
    gestor_libros.libros.append(libro)
    gestor_libros.guardar()

def borrar_libro() -> None:
    print("\n--- Borrar libro ---")
    codigo: str = input("Código del libro a borrar: ")
    gestor_libros.libros = [l for l in gestor_libros.listar() if l.codigo != codigo]
    gestor_libros.guardar()

def filtrar_libros() -> None:
    print("\n--- Filtrar libros por autor ---")
    autor: str = input("Autor a buscar: ")
    filtrados: List[Libro] = [l for l in gestor_libros.listar() if autor.lower() in l.autor.lower()]
    for libro in filtrados:
        print(libro.__dict__)

def editar_libro() -> None:
    print("\n--- Editar libro ---")
    codigo: str = input("Código del libro a editar: ")
    for libro in gestor_libros.listar():
        if libro.codigo == codigo:
            titulo: str = input("Nuevo título: ")
            autor: str = input("Nuevo autor: ")
            if titulo:
                libro.titulo = titulo
            if autor:
                libro.autor = autor
            gestor_libros.guardar()
            print("Libro actualizado.")
            return
    print("Libro no encontrado.")

def buscar_y_mostrar_libro() -> None:
    codigo: str = input("Ingresa el código del libro a buscar: ")
    libro: Optional[Libro] = gestor_libros.buscar_libro_por_codigo(codigo)
    if libro:
        print("Libro encontrado:")
        print(libro.__dict__)
    else:
        print("Libro no encontrado.")

def borrar_todo_libros():
    libros = gestor_libros.listar()
    for libro in libros:
        gestor_libros.borrar(libro.codigo)
    print("Todos los libros han sido eliminados.")


def guardar_libros():
    gestor_libros.guardar()
    print("Los datos de libros han sido guardados en el archivo.")

