from libro import Libro
from prestamo import Prestamo
from gestores.gestor_libros import GestorLibros
from gestores.gestor_prestamos import GestorPrestamos
from datetime import date, datetime
from typing import Optional, List

gestor_libros = GestorLibros()
gestor_prestamos = GestorPrestamos()

def listar_prestamos() -> None:
    print("\n--- Lista de préstamos ---")
    for p in gestor_prestamos.listar():
        print(p.a_dict())

def crear_prestamo() -> None:
    print("\n--- Crear préstamo ---")
    alumno_id: str = input("ID alumno: ")
    libro_codigo: str = input("Código libro: ")

    libro: Optional[Libro] = gestor_libros.buscar_libro_por_codigo(libro_codigo)
    if not libro:
        print("Libro no encontrado.")
        return

    id: str = generar_id_prestamo()

    gestor_prestamos.crear_prestamo(id, alumno_id, libro_codigo)

    libro.disponible = False
    gestor_libros.guardar()

    print(f"Préstamo {id} creado y disponibilidad actualizada.")

def devolver_libro() -> None:
    print("\n--- Devolver libro ---")
    id_prestamo: str = input("ID del préstamo a devolver: ")
    for p in gestor_prestamos.listar():
        if p.id == id_prestamo:
            if p.fecha_devolucion:
                print("Este préstamo ya fue devuelto.")
                return
            p.fecha_devolucion = date.today().isoformat()
            gestor_prestamos.guardar()

            libro: Optional[Libro] = gestor_libros.buscar_libro_por_codigo(p.libro_codigo)
            if libro:
                libro.disponible = True
                gestor_libros.guardar()

            print("Libro devuelto y disponibilidad actualizada.")
            return
    print("Préstamo no encontrado.")

def generar_id_prestamo() -> str:
    return f"PRESTAMO_{datetime.now().strftime('%Y%m%d%H%M%S')}"

def guardar_prestamos() -> None:
    gestor_prestamos.guardar()
    print("Los datos de los préstamos han sido guardados en el archivo.")

def filtrar_prestamos_por_alumno() -> None:
    alumno_id: str = input("Ingrese el ID del alumno para filtrar préstamos: ")
    prestamos: List[Prestamo] = gestor_prestamos.filtrar_prestamos_por_alumno(alumno_id)
    if prestamos:
        print(f"\n--- Préstamos del alumno {alumno_id} ---")
        for p in prestamos:
            print(p.a_dict())
    else:
        print("No se encontraron préstamos para este alumno.")

def filtrar_prestamos_por_libro() -> None:
    libro_codigo: str = input("Ingrese el código del libro para filtrar préstamos: ")
    prestamos: List[Prestamo] = gestor_prestamos.filtrar_prestamos_por_libro(libro_codigo)
    if prestamos:
        print(f"\n--- Préstamos del libro {libro_codigo} ---")
        for p in prestamos:
            print(p.a_dict())
    else:
        print("No se encontraron préstamos para este libro.")
