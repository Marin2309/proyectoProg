import csv
import os
import re
from alumno import Alumno
from typing import List, Optional, Dict


class GestorAlumnos:
    def __init__(self, ruta: str = 'data/alumnos.csv'):
        self.ruta: str = ruta
        if not os.path.exists(self.ruta):
            os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
            with open(self.ruta, 'w', encoding='utf-8') as f:
                f.write('id,nombre,apellido,email,dni,curso\n')  # Añadido 'curso'
        self.alumnos: List[Alumno] = self.cargar()

    def cargar(self) -> List[Alumno]:
        alumnos: List[Alumno] = []
        if os.path.exists(self.ruta):
            with open(self.ruta, 'r', encoding='utf-8') as f:
                lineas: List[str] = f.readlines()
                if lineas:
                    for line in lineas[1:]:
                        line = line.strip()
                        if not line:
                            continue
                        fila: List[str] = line.split(',')
                        if len(fila) < 6:  # Cambiado a 6 para incluir curso
                            continue
                        alumno: Alumno = Alumno(
                            id=fila[0],
                            nombre=fila[1],
                            apellido=fila[2],
                            email=fila[3],
                            dni=fila[4],
                            curso=fila[5]  # Añadido curso
                        )
                        alumnos.append(alumno)
        return alumnos

    def guardar(self) -> None:
        os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
        with open(self.ruta, 'w', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['id', 'nombre', 'apellido', 'email', 'dni', 'curso'])
            writer.writeheader()
            for alumno in self.alumnos:
                writer.writerow(alumno.a_dict())

    def listar(self) -> List[Alumno]:
        return self.alumnos

    def validar_email(self, email: str) -> bool:
        # Validar el formato del email
        regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(regex, email) is not None

    def solicitar_datos_alumno(self) -> Alumno:
        while True:
            id: str = input("ID: ")
            nombre: str = input("Nombre: ")
            apellido: str = input("Apellido: ")

            email: str = input("Email: ")
            while not self.validar_email(email):
                print("Email no válido. Por favor, ingrese un email válido.")
                email = input("Email: ")

            dni: str = input("DNI: ")
            curso: str = input("Curso: ")

            return Alumno(id, nombre, apellido, email, dni, curso)

    def agregar(self, alumno: Alumno) -> None:
        if any(a.id == alumno.id for a in self.alumnos):
            print(f"Ya existe un alumno con ID {alumno.id}")
            return
        self.alumnos.append(alumno)
        self.guardar()

    def borrar(self, alumno_id: str) -> None:
        self.alumnos = [a for a in self.alumnos if a.id != alumno_id]
        self.guardar()

    def filtrar_por_nombre(self, nombre: str) -> List[Alumno]:
        return [a for a in self.alumnos if nombre.lower() in a.nombre.lower()]

    def editar(self, alumno_id: str, nuevos_datos: Dict[str, str]) -> None:
        for a in self.alumnos:
            if a.id == alumno_id:
                a.nombre = nuevos_datos.get('nombre', a.nombre)
                a.apellido = nuevos_datos.get('apellido', a.apellido)
                a.email = nuevos_datos.get('email', a.email)
                a.dni = nuevos_datos.get('dni', a.dni)  # Actualizar DNI
                a.curso = nuevos_datos.get('curso', a.curso)  # Actualizar curso
                self.guardar()
                return
        print("Alumno no encontrado.")

    def buscar_alumno_por_id(self, alumno_id: str) -> Optional[Alumno]:
        for alumno in self.alumnos:
            if alumno.id == alumno_id:
                return alumno
        return None

    def exportar_alumnos(self, ruta_exportacion: str) -> None:
        # Asegurarse de que el directorio de exportación exista
        os.makedirs(os.path.dirname(ruta_exportacion), exist_ok=True)

        with open(ruta_exportacion, 'w', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['id', 'nombre', 'apellido', 'email', 'dni', 'curso'])
            writer.writeheader()
            for alumno in self.alumnos:
                writer.writerow(alumno.a_dict())
        print(f"Datos exportados a {ruta_exportacion}.")

    def importar_alumno(self, ruta_importacion: str) -> None:
        if not os.path.exists(ruta_importacion):
            print("El archivo de importación no existe.")
            return

        with open(ruta_importacion, 'r', encoding='utf-8') as f:
            lineas: List[str] = f.readlines()
            if len(lineas) == 0 or len(lineas[0].strip().split(',')) < 6:
                print("Formato del archivo de importación inválido.")
                return

            for line in lineas[1:]:
                line = line.strip()
                if not line:
                    continue
                fila: List[str] = line.split(',')
                if len(fila) < 6:  # Verificar que hay suficientes columnas
                    print("Formato de archivo inválido.")
                    continue
                alumno: Alumno = Alumno(
                    id=fila[0],
                    nombre=fila[1],
                    apellido=fila[2],
                    email=fila[3],
                    dni=fila[4],
                    curso=fila[5]
                )
                self.agregar(alumno)

