import csv
import os
from typing import List, Dict

USERS_FILE = 'data/users.csv'

def create_fichero_usuarios() -> None:
    os.makedirs(os.path.dirname(USERS_FILE), exist_ok=True)
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['username', 'password'])
            writer.writerow(['admin', '1234'])

def autentificar_usuario(username: str, password: str) -> bool:
    create_fichero_usuarios()
    if not os.path.exists(USERS_FILE):
        print("Error: Archivo no encontrado.")
        return False
    with open(USERS_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get('username') == username and row.get('password') == password:
                return True
    return False

def anadir_usuario(username: str, password: str) -> None:
    create_fichero_usuarios()
    existing_users: List[Dict[str, str]] = []
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            existing_users = list(reader)
    if any(user['username'] == username for user in existing_users):
        print(f"El usuario '{username}' ya existe.")
        return
    with open(USERS_FILE, 'a', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([username, password])
    print(f"Usuario '{username}' añadido correctamente.")


