import csv
import os
from libro import Libro
from typing import List, Optional, Dict

class GestorLibros:
    def __init__(self, ruta: str = 'data/libros.csv'):
        self.ruta: str = ruta
        if not os.path.exists(self.ruta):
            os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
            with open(self.ruta, 'w', encoding='utf-8') as f:
                f.write('codigo,titulo,autor,materia,disponible\n')  # Encabezados
        self.libros: List[Libro] = self.cargar()

    def cargar(self) -> List[Libro]:
        libros: List[Libro] = []
        if os.path.exists(self.ruta):
            with open(self.ruta, 'r', encoding='utf-8') as f:
                lineas = f.readlines()
                if lineas:
                    for line in lineas[1:]:
                        fila = line.strip().split(',')
                        if len(fila) < 5:
                            continue
                        libro = Libro(
                            codigo=fila[0],
                            titulo=fila[1],
                            autor=fila[2],
                            materia=fila[3],
                            disponible=fila[4].lower() == 'true'  # Convertir a booleano
                        )
                        libros.append(libro)
        return libros

    def guardar(self) -> None:
        os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
        with open(self.ruta, 'w', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['codigo', 'titulo', 'autor', 'materia', 'disponible'])
            writer.writeheader()
            for libro in self.libros:
                writer.writerow(libro.a_dict())

    def listar(self) -> List[Libro]:
        return self.libros

    def buscar_libro_por_codigo(self, codigo: str) -> Optional[Libro]:
        for libro in self.libros:
            if libro.codigo == codigo:
                return libro
        return None

    def editar_libro(self, codigo: str, nuevos_datos: Dict[str, str]) -> None:
        libro: Optional[Libro] = self.buscar_libro_por_codigo(codigo)
        if libro:
            libro.titulo = nuevos_datos.get('titulo', libro.titulo)
            libro.autor = nuevos_datos.get('autor', libro.autor)
            self.guardar()
            print("Libro actualizado correctamente.")
        else:
            print("Libro no encontrado.")

    def borrar(self, codigo: str) -> None:
        self.libros = [a for a in self.libros if a.codigo != codigo]
        self.guardar()

    def agregar_libro(self, libro: Libro) -> None:
        if any(a.codigo == libro.codigo for a in self.libros):
            print(f"Ya existe un libro con ese codigo: {libro.codigo}")
            return
        self.libros.append(libro)
        self.guardar()

