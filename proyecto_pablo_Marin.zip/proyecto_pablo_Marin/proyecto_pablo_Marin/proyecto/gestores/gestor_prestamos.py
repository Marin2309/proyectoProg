import os
import csv
from datetime import date
from prestamo import Prestamo
from typing import List, Optional, Dict, Any

class GestorPrestamos:
    def __init__(self, ruta: str = 'data/prestamos.csv'):
        self.ruta: str = ruta
        os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
        if not os.path.exists(self.ruta):
            with open(self.ruta, 'w', encoding='utf-8') as f:
                f.write('id,alumno_id,libro_codigo,fecha_prestamo,fecha_devolucion\n')
        self.prestamos: List[Prestamo] = self.cargar()

    def cargar(self) -> List[Prestamo]:
        prestamos: List[Prestamo] = []
        if os.path.exists(self.ruta):
            try:
                with open(self.ruta, 'r', encoding='utf-8') as f:
                    lineas: List[str] = f.readlines()
                    if lineas:
                        for line in lineas[1:]:
                            line = line.strip()
                            if not line:
                                continue
                            fila: List[str] = line.split(',')
                            if len(fila) != 5:
                                continue
                            prestamo: Prestamo = Prestamo(
                                id=fila[0],
                                alumno_id=fila[1],
                                libro_codigo=fila[2],
                                fecha_prestamo=fila[3],
                                fecha_devolucion=fila[4] if fila[4] else None
                            )
                            prestamos.append(prestamo)
            except Exception as e:
                print(f"Error cargando préstamos: {e}")
        return prestamos

    def guardar(self) -> None:
        os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
        with open(self.ruta, 'w', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['id', 'alumno_id', 'libro_codigo', 'fecha_prestamo', 'fecha_devolucion'])
            writer.writeheader()
            for p in self.prestamos:
                writer.writerow(p.a_dict())

    def listar(self) -> List[Prestamo]:
        return self.prestamos

    def crear_prestamo(self, id: str, alumno_id: str, libro_codigo: str) -> None:
        if self.es_libro_prestado(libro_codigo):
            print("El libro ya está prestado.")
            return
        today: str = date.today().isoformat()
        prestamo: Prestamo = Prestamo(id, alumno_id, libro_codigo, today)
        self.prestamos.append(prestamo)
        self.guardar()

    def devolver_libro(self, id_prestamo: str) -> None:
        for p in self.prestamos:
            if p.id == id_prestamo:
                if p.fecha_devolucion:
                    print("Este préstamo ya está cerrado.")
                    return
                p.fecha_devolucion = date.today().isoformat()
                self.guardar()
                return
        print("Préstamo no encontrado.")

    def es_libro_prestado(self, libro_codigo: str) -> bool:
        for p in self.prestamos:
            if p.libro_codigo == libro_codigo and p.fecha_devolucion is None:
                return True
        return False

    def filtrar_prestamos_por_alumno(self, alumno_id: str) -> List[Prestamo]:
        return [p for p in self.prestamos if p.alumno_id == alumno_id]

    def filtrar_prestamos_por_libro(self, libro_codigo: str) -> List[Prestamo]:
        return [p for p in self.prestamos if p.libro_codigo == libro_codigo]
