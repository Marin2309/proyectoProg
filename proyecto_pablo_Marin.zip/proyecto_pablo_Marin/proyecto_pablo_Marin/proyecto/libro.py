from typing import Dict, Any

class Libro:
    def __init__(self, codigo: str, titulo: str, autor: str, materia: str, disponible: bool):
        self.codigo = codigo
        self.titulo = titulo
        self.autor = autor
        self.materia = materia
        self.disponible = disponible

    def a_dict(self) -> Dict[str, Any]:
        return {
            'codigo': self.codigo,
            'titulo': self.titulo,
            'autor': self.autor,
            'materia': self.materia,
            'disponible': self.disponible
        }
