from menu import menu_validaciones

if __name__ == '__main__':
    menu_validaciones()

