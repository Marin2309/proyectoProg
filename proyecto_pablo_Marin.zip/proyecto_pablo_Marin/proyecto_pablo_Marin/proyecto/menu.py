from gestores.gestor_auth import *
from menus.menu_principal import mostrar_menu_principal
from typing import NoReturn

def menu_validaciones() -> NoReturn:

    while True:
        print("\n=== Menú de Acceso ===")
        print("1. Iniciar Sesión")
        print("2. Crear Nuevo Usuario")
        print("0. Salir del Programa")
        opcion = input("Selecciona una opción: ")

        if opcion == '1':
            username = input("Usuario: ")
            password = input("Contraseña: ")
            if autentificar_usuario(username, password):
                print("¡Inicio de sesión exitoso!")
                mostrar_menu_principal()
            else:
                print("Usuario o contraseña incorrectos. Inténtalo de nuevo.")

        elif opcion == '2':
            print("\n--- Crear Nuevo Usuario ---")
            new_username = input("Ingrese el nombre de usuario para el nuevo usuario: ")
            new_password = input("Ingrese la contraseña para el nuevo usuario: ")
            anadir_usuario(new_username, new_password)
            print("Usuario creado exitosamente. Puedes iniciar sesión ahora.")

        elif opcion == '0':
            print("Saliendo del programa.")
            break

        else:
            print("Opción no válida. Por favor, ingresa 1, 2 o 0.")
