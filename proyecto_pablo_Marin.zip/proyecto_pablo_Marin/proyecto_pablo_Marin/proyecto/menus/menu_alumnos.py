from funciones.funciones_alumnos import *

def mostrar_menu_alumnos():
    while True:
        print("\n=== Sistema de Gestión ===")
        print("1. Listar alumnos")
        print("2. Agregar alumno")
        print("3. Borrar alumno")
        print("4. Filtrar alumnos por nombre")
        print("5. Buscar Alumno")
        print("6. Editar Alumno")
        print("7. Cargar Alumno")
        print("8. Borrar Todo")
        print("9. Guardar")
        print("10. Exportar fichero")
        print("11. importar fichero")
        print("0. Salir")
        opcion = input("Selecciona una opción: ")

        if opcion == '1':
            listar_alumnos()
        elif opcion == '2':
            agregar_alumno()
        elif opcion == '3':
            borrar_alumno()
        elif opcion == '4':
            filtrar_alumnos()
        elif opcion == '5':
            buscar_y_mostrar_alumno()
        elif opcion == '6':
            editar_alumno()
        elif opcion == '7':
            cargar_alumnos()
        elif opcion == '8':
            borrar_todo_alumnos()
        elif opcion == '9':
            guardar_alumnos()
        elif opcion == '10':
            exportar_fichero()
        elif opcion == '11':
            importar_fichero()
        elif opcion == '0':
            print("Menu Principal")
            break
        else:
            print("Opción no válida.")