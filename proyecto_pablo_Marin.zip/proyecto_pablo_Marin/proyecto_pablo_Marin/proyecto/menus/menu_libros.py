from funciones.funciones_libros import *

def mostrar_menu_libros():
    while True:
        print("\n=== Sistema de Gestión ===")
        print("1. Listar libros")
        print("2. Agregar libro")
        print("3. Borrar libro")
        print("4. Filtrar libros por autor")
        print("5. Filtrar libros por codigo")
        print("6. Borrar todo")
        print("7. Guardar")
        print("0. Salir")
        opcion = input("Selecciona una opción: ")
        if opcion == '1':
            listar_libros()
        elif opcion == '2':
            agregar_libro()
        elif opcion == '3':
            borrar_libro()
        elif opcion == '4':
            filtrar_libros()
        elif opcion == '5':
            buscar_y_mostrar_libro()
        elif opcion == '6':
            borrar_todo_libros()
        elif opcion == '7':
            guardar_libros()
        elif opcion == '0':
            print("Menu Principal")
            break
        else:
            print("Opción no válida.")