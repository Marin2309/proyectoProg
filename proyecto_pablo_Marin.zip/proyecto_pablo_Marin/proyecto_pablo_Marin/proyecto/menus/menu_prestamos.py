from funciones.funciones_prestamos import *

def mostrar_menu_prestamos():
    while True:
        print("\n=== Sistema de Gestión ===")
        print("1. Listar préstamos")
        print("2. Crear préstamo")
        print("3. Devolver libro")
        print("4. Filtrar prétamos por id alumno")
        print("5. Filtrar prétamos por codigo libro")
        print("6. Guardar")
        print("0. Salir")
        opcion = input("Selecciona una opción: ")

        if opcion == '1':
            listar_prestamos()
        elif opcion == '2':
            crear_prestamo()
        elif opcion == '3':
            devolver_libro()
        elif opcion == '4':
            filtrar_prestamos_por_alumno()
        elif opcion == '5':
            filtrar_prestamos_por_libro()
        elif opcion == '6':
            guardar_prestamos()
        elif opcion == '0':
            print("¡Hasta luego!")
            break
        else:
            print("Opción no válida.")