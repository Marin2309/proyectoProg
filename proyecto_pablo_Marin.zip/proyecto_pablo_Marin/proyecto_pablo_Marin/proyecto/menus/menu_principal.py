from menus.menu_alumnos import mostrar_menu_alumnos
from menus.menu_libros import mostrar_menu_libros
from menus.menu_prestamos import mostrar_menu_prestamos

from typing import NoReturn

def mostrar_menu_principal() -> NoReturn:
    while True:
        print("\n=== Sistema de Gestión ===")
        print("1. Menu alumnos")
        print("2. Menu libros")
        print("3. Menu prestamos")
        print("0. Salir")
        opcion: str = input("Selecciona una opción: ")

        if opcion == '1':
            mostrar_menu_alumnos()
        elif opcion == '2':
            mostrar_menu_libros()
        elif opcion == '3':
            mostrar_menu_prestamos()
        elif opcion == '0':
            print("¡Hasta luego!")

            break
        else:
            print("Opción no válida.")
