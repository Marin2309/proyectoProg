from typing import Optional, Dict, Any

class Prestamo:
    def __init__(self, id: str, alumno_id: str, libro_codigo: str, fecha_prestamo: str, fecha_devolucion: Optional[str] = None):
        self.id: str = id
        self.alumno_id: str = alumno_id
        self.libro_codigo: str = libro_codigo
        self.fecha_prestamo: str = fecha_prestamo
        self.fecha_devolucion: Optional[str] = fecha_devolucion

    def a_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'alumno_id': self.alumno_id,
            'libro_codigo': self.libro_codigo,
            'fecha_prestamo': self.fecha_prestamo,
            'fecha_devolucion': self.fecha_devolucion or ''
        }
