import os
from gestores.gestor_alumnos import GestorAlumnos
from alumno import Alumno

# Es lo mismo que un CD
os.chdir('..')

def test_todas_funcionalidades_alumno():
    gestor = GestorAlumnos()

    # Borrar si existe el alumno de prueba
    gestor.borrar('TEST')

    # Crear alumno
    alumno = Alumno('TEST', 'Pablo', 'Marin', 'pablo@gmail.com', '12345678A', 'Matemáticas')
    gestor.agregar(alumno)
    assert gestor.buscar_alumno_por_id('TEST') is not None, "Error: no se pudo crear alumno"
    print("Creación: OK")

    # Listar alumnos
    print("\nListado de alumnos: OK")
    for a in gestor.listar():
        print(a.a_dict())

    # Buscar por ID
    alumno_buscado = gestor.buscar_alumno_por_id('TEST')
    assert alumno_buscado is not None, "Error: no se encontró alumno"
    print("Buscar por ID: OK")

    # Filtrar por nombre
    filtrados = gestor.filtrar_por_nombre('Pablo')
    assert len(filtrados) >= 1, "Error: filtro por nombre no funciona"
    print("Filtrar por nombre: OK")

    # Editar alumno
    gestor.editar('TEST', {'nombre': 'Carlos', 'email': 'carlos@gmail.com', 'curso': 'Historia'})
    alumno_editado = gestor.buscar_alumno_por_id('TEST')
    assert alumno_editado.nombre == 'Carlos', "Error: edición del nombre falló"
    assert alumno_editado.email == 'carlos@gmail.com', "Error: edición del email falló"
    assert alumno_editado.curso == 'Historia', "Error: edición del curso falló"
    print("Editar: OK")

    # Listar alumnos para verificar cambios
    print("\nListado tras editar: OK")
    for a in gestor.listar():
        print(a.a_dict())

    # Borrar alumno
    gestor.borrar('TEST')
    assert gestor.buscar_alumno_por_id('TEST') is None, "Error: no se pudo borrar alumno"
    print("Borrar: OK")

    print("Todos los pasos de gestión de alumno pasaron correctamente y sin residuos.")

if __name__ == "__main__":
    test_todas_funcionalidades_alumno()
