import os
from gestores.gestor_auth import *

os.chdir('..')


def test_auth():
    # Comprobar si el archivo existe y guardar los datos actuales
    if os.path.exists('data/users.csv'):
        with open('data/users.csv', 'r', encoding='utf-8') as f:
            original_data = f.readlines()

    # Crear archivo por primera vez con la función
    create_fichero_usuarios()

    # Verificar que el usuario admin funciona
    assert autentificar_usuario('admin', '1234') == True, "Error: usuario admin no autenticó correctamente"

    # Añadir un nuevo usuario
    anadir_usuario('pablo', '1234')
    # Verificar que el nuevo usuario funciona
    assert autentificar_usuario('pablo', '1234') == True, "Error: nuevo usuario no autenticó correctamente"

    # Verificar que un usuario incorrecto no pasa
    assert autentificar_usuario('pablo', '123') == False, "Error: contraseña incorrecta pasó la autenticación"

    # Intentar agregar un usuario existente
    anadir_usuario('pablo', '1234')  # Solo muestra mensaje, no falla
    # Verificar que la contraseña no cambió
    assert autentificar_usuario('pablo',
                                '1234') == True, "Error: contraseña del usuario existente cambió inesperadamente"

    # Limpia el archivo dejando solo la cabecera
    with open('data/users.csv', 'w', encoding='utf-8') as f:
        f.write('username,password\n')
    print("Archivo dejado vacío, solo con la cabecera.")

    # Restaurar los datos originales si existían
    if 'original_data' in locals():
        with open('data/users.csv', 'w', encoding='utf-8') as f:
            f.writelines(original_data)  # Restaurar el archivo original
        print("Datos originales restaurados en el archivo.")

    print("Todas las pruebas de auth pasaron correctamente.")


if __name__ == "__main__":
    test_auth()
