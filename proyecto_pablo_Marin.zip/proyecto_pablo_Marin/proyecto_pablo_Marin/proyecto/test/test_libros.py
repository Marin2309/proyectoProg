import os
from gestores.gestor_libros import GestorLibros
from libro import Libro

os.chdir('..')

def test_completo_libro():
    gestor = GestorLibros()

    gestor.borrar('LTEST')

    # Crear libro
    libro = Libro('LTEST', 'El Principito', 'Antoine de Saint-Exupéry', 'Literatura', True)
    gestor.agregar_libro(libro)  # Usar el método agregar en lugar de append
    assert gestor.buscar_libro_por_codigo('LTEST') is not None, "Error: no se pudo crear libro"
    print("Creación: OK")

    # Verificar datos
    libro_buscado = gestor.buscar_libro_por_codigo('LTEST')
    assert libro_buscado.titulo == 'El Principito', "Error: título incorrecto"
    assert libro_buscado.autor == 'Antoine de Saint-Exupéry', "Error: autor incorrecto"
    assert libro_buscado.materia == 'Literatura', "Error: materia incorrecta"
    print("Verificación creación: OK")

    # Editar libro
    gestor.editar_libro('LTEST', {'titulo': 'El Principito - Edición'})
    libro_editado = gestor.buscar_libro_por_codigo('LTEST')
    assert libro_editado.titulo == 'El Principito - Edición', "Error: edición del título falló"
    print("Edición: OK")

    # Cambiar disponibilidad a False (simular préstamo)
    libro_editado.disponible = False
    gestor.guardar()
    libro = gestor.buscar_libro_por_codigo('LTEST')
    assert libro.disponible is False, "Error: cambio a no disponible falló"
    print("Cambio disponibilidad: OK")

    # Borrar libro
    gestor.borrar('LTEST')
    assert gestor.buscar_libro_por_codigo('LTEST') is None, "Error: no se pudo borrar libro"
    print("Borrado: OK")

    print("Todos los pasos para libro pasaron sin residuos.")

if __name__ == "__main__":
    test_completo_libro()
