import os
from datetime import datetime
from gestores.gestor_prestamos import GestorPrestamos
from prestamo import Prestamo

os.chdir('..')

def test_gestor_prestamos():
    gestor = GestorPrestamos()

    # Guardar los datos originales
    original_data = []
    if os.path.exists(gestor.ruta):
        with open(gestor.ruta, 'r', encoding='utf-8') as f:
            original_data = f.readlines()

    # Limpiar los préstamos existentes solo para evitar conflictos en pruebas
    gestor.prestamos = []
    gestor.guardar()

    # Crear un préstamo
    id_prestamo = f"PREST_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    alumno_id = 'ALU001'
    libro_codigo = 'LIB001'
    gestor.crear_prestamo(id_prestamo, alumno_id, libro_codigo)

    # Verificar que el préstamo se creó
    p = None
    for prestamo in gestor.listar():
        if prestamo.id == id_prestamo:
            p = prestamo
            break
    assert p is not None, "Error: no se creó el préstamo"
    print(f"Préstamo creado con ID: {p.id}")

    # Ver que el préstamo no tiene devolución
    assert p.fecha_devolucion is None, "Error: la fecha_devolucion debería ser None"
    print("Estado antes de devolver: OK")

    # Devolver el libro
    gestor.devolver_libro(p.id)

    # Verificar que la fecha de devolución se actualizó
    p2 = None
    for prestamo in gestor.listar():
        if prestamo.id == p.id:
            p2 = prestamo
            break
    assert p2 is not None, "Error: no se encontró el préstamo después de devolver"
    assert p2.fecha_devolucion is not None, "Error: no se actualizó la fecha de devolución"
    print(f"Fecha de devolución: {p2.fecha_devolucion}")

    # Restaurar los datos originales
    if original_data:
        with open(gestor.ruta, 'w', encoding='utf-8') as f:
            f.writelines(original_data)
        print("Datos originales restaurados en el archivo.")

    print("Todos los tests sobre gestor_prestamos pasaron correctamente.")

if __name__ == "__main__":
    test_gestor_prestamos()
